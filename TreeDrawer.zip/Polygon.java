/*
 * Polygon.java 
 */

package VC.TreeDrawer;

class Polygon {
    Polyline lower_head, lower_tail;
    Polyline upper_head, upper_tail;
}
